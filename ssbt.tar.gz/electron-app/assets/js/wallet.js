let connectionInstance, stompClientInstance, mainWindowInstance, secondaryWindowInstance

class Wallet {
  constructor(connection, stompClient, mainWindow, secondaryWindow){
    connectionInstance = connection
    stompClientInstance = stompClient
    mainWindowInstance = mainWindow
    secondaryWindowInstance = secondaryWindow

  }

  failureCallback(response){
    console.error('Error wallet->'+response)
  }


  /* TOPICS*/ 

  subscribeMoneyIn(callback){
    connectionInstance.subscribe('/topic/moneyIn', callback, this.failureCallback)
  }

  subscribeVoucherProcess(callback){
    connectionInstance.subscribe('/topic/processVoucher', callback, this.failureCallback)
  }

  subscribeWithdrawVoucherProcess(callback){
    connectionInstance.subscribe('/topic/createVoucher', callback, this.failureCallback)
  }

  subscribeWithdrawToOnline(callback){
    connectionInstance.subscribe('/topic/withdrawToOnline', callback, this.failureCallback)
  }

  subscribeFundWithOnline(callback){
    connectionInstance.subscribe('/topic/fundWithOnline', callback, this.failureCallback)
  }

  /*WEB SOCKET*/ 

  sendVoucherCode(voucherCode){
    stompClientInstance.send("/ssbt/processVoucher", {}, JSON.stringify( {'voucherCode': voucherCode.toUpperCase() }));
  }

  createWithdrawVoucherCode(tradingBalance){
    stompClientInstance.send("/ssbt/createVoucher", {}, tradingBalance );
  }

  withdrawToOnline(message){
    stompClientInstance.send("/ssbt/withdrawToOnline", {}, JSON.stringify(message));
  }

  fundWithOnline(message){
    console.log(message)
    stompClientInstance.send("/ssbt/fundWithOnline", {}, JSON.stringify(message));
  }

}

module.exports = Wallet
