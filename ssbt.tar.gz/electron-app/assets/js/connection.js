const SockJS = require('sockjs-client');
var Stomp = require('stompjs');
const app = require('../../main.js');

const debug = /--debug/.test(process.argv[2]);

let stompClient

class Connection {


  constructor(settings, callback, failureCallback){
    this.initialize(settings, callback, failureCallback);
    this.stompClient = stompClient;
  }

  initialize (settings, callback, failureCallback){
    let ws = new SockJS(settings.url);
    this.connect(ws, callback, failureCallback);
  }

  connect(ws, callback, failureCallback){
    stompClient = Stomp.over(ws);
    stompClient.connect({}, callback, failureCallback);
  }

  subscribe(id, success, failure){
    debug && console.log('********  subscribed to ->'+id);
    stompClient.subscribe(id, function (data) {
      debug && console.log(data.body)
      success(JSON.parse(data.body));
    },function (data) {
      failure(JSON.parse(data.body));
    });
  }

}

module.exports = Connection
