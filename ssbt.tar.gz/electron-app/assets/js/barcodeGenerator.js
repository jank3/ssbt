const http = require('http');
//https://lindell.me/JsBarcode/
const base64test = "iVBORw0KGgoAAAANSUhEUgAAAVAAAAAyCAYAAAAKo4M8AAACYUlEQVR4Xu3W0UrDQBhE4eT9HzoltQs/SyFeDXT4eqES407mOD16HsdxHfeH6zrO83x/vl/z6/eFh2v3/eucb/eu76+zZt5T1jx73fuUtz/DzJ8dZ/f9+eezzvP2s3Zu/+Gw817nz5+d1/bf0XiGP/BeCCAQJ3C/+Qj088eDQOP7E4jATxMg0PHfN4H+9JY9PAJxAgRKoPHRCUSghQCBEmjLlvVAIE6AQAk0PjqBCLQQIFACbdmyHgjECRAogcZHJxCBFgIESqAtW9YDgTgBAiXQ+OgEItBCgEAJtGXLeiAQJ0CgBBofnUAEWggQKIG2bFkPBOIECJRA46MTiEALAQIl0JYt64FAnACBEmh8dAIRaCFAoATasmU9EIgTIFACjY9OIAItBAiUQFu2rAcCcQIESqDx0QlEoIUAgRJoy5b1QCBOgEAJND46gQi0ECBQAm3Zsh4IxAkQKIHGRycQgRYCBEqgLVvWA4E4AQIl0PjoBCLQQoBACbRly3ogECdAoAQaH51ABFoIECiBtmxZDwTiBAiUQOOjE4hACwECJdCWLeuBQJwAgRJofHQCEWghQKAE2rJlPRCIEyBQAo2PTiACLQQIlEBbtqwHAnECBEqg8dEJRKCFAIESaMuW9UAgToBACTQ+OoEItBAgUAJt2bIeCMQJECiBxkcnEIEWAgRKoC1b1gOBOAECJdD46AQi0EKAQAm0Zct6IBAnQKAEGh+dQARaCBAogbZsWQ8E4gQIlEDjoxOIQAsBAiXQli3rgUCcAIESaHx0AhFoIUCgBNqyZT0QiBMgUAKNj04gAi0EXlEXxzK/fyMOAAAAAElFTkSuQmCC"
const codeURL = "http://129.146.68.122:10086/common/code128.ashx?"

class BarcodeGenerator {

  static generateCode (code, callback){

    
    let barcodeUrl = codeURL + '&code='+ code ;
    console.log(codeURL)
    console.log(code)

    http.get(barcodeUrl, (resp) => {
      let data = '';

      // A chunk of data has been recieved.
      resp.on('data', (chunk) => {
        data += chunk;
      });

      // The whole response has been received. Print out the result.
      resp.on('end', () => {
        callback(data)
      });

    }).on("error", (err) => {
      console.log("Error: " + err.message);
      callback (base64test)
    });
  }
}

module.exports = BarcodeGenerator