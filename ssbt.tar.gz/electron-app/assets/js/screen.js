const electron = require('electron')
const {app,BrowserWindow} = require('electron')
const url = require('url')
const {ipcMain} = require('electron');

//let this.mainWindow,this.secondaryWindow, this.modalWindow
let flip = false;
let x1,y1,x2,y2;
let debug = false
const SSBT = require('../../configuration.json');
let defaultSettings;


class Screen {
  constructor(settings, isDebug){

    this.initialize = true;
    this.mainWindow = null;
    this.secondaryWindow = null;
    this.modalWindow = null;
    debug = isDebug;
    defaultSettings = settings;
    defaultSettings.webPreferences.preload = app.getAppPath() + '/assets/js/preload.js'
  
    this.initializeScreen()
  }

  initializeScreen (){

    this.setScreenPosition()
    this.createMainWindow()
    this.createSecondaryWindow(x2, y2);
    
    this.createModal('user')
  }

  setScreenPosition(){
    let displays = electron.screen.getAllDisplays()
    let externalDisplay = displays.find((display) => {
      return display.bounds.x !== 0 || display.bounds.y !== 0
    })
  
    let primaryDisplay = displays.find((display) => {
      return display.bounds.x === 0 || display.bounds.y === 0
    })
    
    x1 = primaryDisplay.bounds.width
    y1 = primaryDisplay.bounds.height

    
    if (externalDisplay) {
      x2 = externalDisplay.bounds.x
      y2 = externalDisplay.bounds.y
    }
  }

  createMainWindow(){
    // Create the browser window.
    //this.mainWindow = new BrowserWindow({webPreferences})
    this.mainWindow = new BrowserWindow(defaultSettings)

    if(debug){
      this.mainWindow.loadURL(SSBT.home1, {"extraHeaders" : "pragma: no-cache\n"})
    }else{
      this.mainWindow.loadURL(SSBT.home1)
    }

    const ses = this.mainWindow.webContents.session;
    ses.clearStorageData()
    
    
    this.mainWindow.setMenu(null);
  
    // Launch fullscreen with DevTools open, usage: npm run debug
    if (debug) {
      this.mainWindow.webContents.openDevTools()
      //this.mainWindow.maximize()
      require('devtron').install()

      this.mainWindow.webContents.session.flushStorageData();
    }

    // Emitted when the window is closed.
    this.mainWindow.on('closed', function () {
      app.quit()
    })
   
  
  }
  
  createSecondaryWindow (x, y){
    // Create the browser window.
    defaultSettings.x = x
    defaultSettings.y = y

    this.secondaryWindow = new BrowserWindow(defaultSettings)
  
    if(debug){
      this.secondaryWindow.loadURL(SSBT.home2, {"extraHeaders" : "pragma: no-cache\n"})
    }else{
      this.secondaryWindow.loadURL(SSBT.home2)
    }

    const ses = this.secondaryWindow.webContents.session;
    ses.clearStorageData()
  
    // Launch fullscreen with DevTools open, usage: npm run debug
    if (debug) {
      this.secondaryWindow.webContents.openDevTools()
      //this.secondaryWindow.maximize()
      require('devtron').install()

      this.secondaryWindow.webContents.session.flushStorageData();
    }
    /*
    this.secondaryWindow.webContents.enableDeviceEmulation({
      screenPosition: 'mobile',
    });
  */
    // Emitted when the window is closed.
    this.secondaryWindow.on('closed', function () {
      app.quit()
    })
  }
  
  createModal (modal, message, large){
    let width = large ? 1200 : 900;
    let coorX = large ? (x1-1200)/2 : (x1-900)/2 
    let coorY = (y1-600)/2

    let modalSettigns = { width: width, parent: this.secondaryWindow, modal: true, x: coorX, y: coorY, alwaysOnTop: true, frame: false, show: false , webPreferences : {nodeIntegration: false, preload: app.getAppPath() + '/assets/js/preload.js' }}

    this.modalWindow = null;
    this.modalWindow = new BrowserWindow(modalSettigns)
    var URL = url.format({ slashes: true, protocol: 'file:', pathname: app.getAppPath() + '/assets/pages/'+modal+'/index.html' })
    this.modalWindow.loadURL(URL);

    // Launch fullscreen with DevTools open, usage: npm run debug
    if (debug) {
      this.modalWindow.webContents.openDevTools()
      //this.mainWindow.maximize()
      require('devtron').install()
    }
    
    this.modalWindow.once('ready-to-show', () => {
      this.modalWindow.show()
      
      //this.modalWindow.center()
    })

    var _modalWindow = this.modalWindow;
    var _msg = message
    ipcMain.once('modal-ready-dom-loaded-action', () => {
      if(_msg){
        _modalWindow.webContents.send('send-data-render',_msg)
      }
    });

    // Emitted when the window is closed.
    this.modalWindow.on('closed', function () {
      this.modalWindow = null;
      //app.quit()
    })

    this.modalWindow.show();
  }

  closeModal(){
    if(this.modalWindow && this.modalWindow.close){
      try{
        this.modalWindow.close();
      }catch{
        
      }
    }
  }
  createPrintPage (type,message){
    let printWin;
    if (debug){
      printWin = new BrowserWindow({width: 600, height: 600, show: false })
    }
    else{
      printWin = new BrowserWindow({width: 0, height: 0, show: false })
    }
    
    printWin.loadFile('print' +type+ '.html')

    printWin.on('closed', function () {
      printWin = null
    })
    if (debug) {
      printWin.webContents.openDevTools()
    }

    printWin.once('show', function () {
      setTimeout(function(){
        printWin.webContents.send('send-data-render',message)
        
      }, 500)

      setTimeout(function(){
        printWin.webContents.print({silent: true, printBackground: false, deviceName: 'Thermal'})
      }, 1000)
    })

    if (!debug) {
      setTimeout(function(){
        printWin.close();
      },7000)
    }

    printWin.show();
  }

  flipScreen(){
    this.secondaryWindow.setPosition(0, flip ? defaultSettings.height : 0)
    this.mainWindow.setPosition(0,flip ? 0 : defaultSettings.height)
    flip = !flip;
  }
    
}

module.exports = Screen