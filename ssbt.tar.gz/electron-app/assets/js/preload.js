const { ipcRenderer } = require('electron');
require("./barcodeScanner.js")

const SSBT = require('../../configuration.json');

window.electron = window.electron = {},
(function(electron) {


  electron = {
    
    init: function() {
      
      electron.clearAll();

      window.isElectron = true
      window.isHome1 = location.pathname.indexOf('/sports') > -1
      window.ipcRenderer = ipcRenderer
      window.electron = electron

      ipcRenderer.on('update-betslip-render', (event, data) => {
        //INPLAY
        if( window.isElectron && !window.isHome1 && data.remove){

          var _found = _.find(BetslipViewModel.selections(), function(item){
            return item.selection.idfoselection == data.selection.idfoselection
          });

          if(_found){
            Optima.Betslip.addToBetslip(data.selection, data.market, data.url, data.searchAll);  
          }
          
        }
        //PREMATCH
        if(window.isElectron && window.isHome1  && data.add) {
          Optima.Betslip.addToBetslip(data.selection, data.market, data.url, data.searchAll);  
        }
      });
        

      ipcRenderer.on('user-loged-render', (event, message) => {
        
        if (typeof Optima != 'undefined'){
          setTimeout(function(){
            // eslint-disable-next-line no-undef
            Optima.App.loadBalance()
          },500)
        }
      });

      ipcRenderer.on('reload-render', (event, isHome1) => {
        if(!isHome1 === window.isHome1){
          if(location.href.indexOf('/inplay') > -1){
            location.href = '/inplay'
          }else{
            location.href = '/sports'
          }
        }
      });

      ipcRenderer.on('update-balance-render', (event, response) => {
        if(response.error){
          Optima.Dialog.createDialog(Drupal.t('Error'), response.error, null);  
        }else if(response.body && response.body.postJournalResult){
          //var balance = MainViewModel.tradingBalance();
          //MainViewModel.tradingBalance(balance+ (response.amountInBaseCurrency || 0) )
          Optima.App.loadBalance();
        }
        
      });

      ipcRenderer.on('process-bet-reicipt-status-render', (event, data) => {
        if(data && window.isHome1){
          Optima.Dialog.createDialogVoucher(data.receiptCode, data.DOMelement)
        }
        
      });

      ipcRenderer.on('funds-process-voucher-render', (event, response) => {
        if(response.error && window.isHome1){
          Optima.Dialog.createDialog(Drupal.t('Voucher no longer valid'), response.error, null);  
        }else if(response.body){
          Optima.App.loadBalance(); 
          if(window.isHome1){
            Optima.Dialog.createDialog(Drupal.t('Successful deposit'), Drupal.t('You have successfully deposited your funds'), null); 
          }
           
        }
      });

      ipcRenderer.on('withdraw-process-voucher-render', (event, response) => {
        if(response.error && window.isHome1){
          Optima.Dialog.createDialog(Drupal.t('Withdrawal cannot be processed'), response.error, null);  
        }else if(response.body){
          Optima.App.loadBalance(); 
        }
      });

      ipcRenderer.on('process-withdraw-to-online-render', (event, response) => {
        if(response.error && window.isHome1){
          Optima.Dialog.createDialog(Drupal.t('Error'), response.error, null);  
        }else if(response.body ){
          Optima.App.loadBalance(); 
          if (window.isHome1){
            Optima.Dialog.createDialog(Drupal.t('Withdraw to online account'), Drupal.t("Your withdrawal has been requested successfully "), null);    
          }
        }
      });

      ipcRenderer.on('process-fund-with-online-render', (event, response) => {
        if(response.error && window.isHome1){
          Optima.Dialog.createDialog(Drupal.t('Error'), response.error, null);  
        }else if(response.body ){
          Optima.App.loadBalance(); 
          if (window.isHome1){
            Optima.Dialog.createDialog(Drupal.t('Deposit with online account'), Drupal.t("Your funds have been requested successfully "), null);    
          }
        }
      });

      ipcRenderer.on('add-tab-and-nav-render', (event, data) => {
        if (window.isHome1){
          MainViewModel.addTabAndNav(data.eventname, data.href);   
        }
      });

      ipcRenderer.on('load-balance-render', () => {
        if (!window.isHome1){
          Optima.App.loadBalance(true);
        }
        
      });

      ipcRenderer.on('lost-connection-render', (event) => {
        if (window.isHome1){
          Optima.Dialog.createDialog(Drupal.t('Lost Connection'), Drupal.t("The connection with the Wallet system has been disconnected, please wait"), null);  
        }
      });

      ipcRenderer.on('connection-off-render', (event) => {
        if(typeof $ !== 'undefined'){
          $('body').addClass('lost-connection')
        }
       
      });

      ipcRenderer.on('connection-ready-render', (event) => {
        if(typeof $ !== 'undefined'){
          $('body').removeClass('lost-connection')
        }
      });

      ipcRenderer.on('user-auto-login-render', (event, loginData) => {
        $.cookie('forceCurrency', loginData.currency);  
        $.cookie('forceIdmmcustomer', loginData.idmmcustomer);
        LoginViewModel.username(loginData.username);
        LoginViewModel.password(loginData.password);
        Optima.Login.loginProcess();
      });

      document.addEventListener('DOMContentLoaded', () => {
        
        electron.bindDOMElements(); 
        if( window.isElectron && window.isHome1 ){
          console.log('******************************')
          setTimeout(function(){
            window.ipcRenderer.send('ready-dom-loaded-action');
          },1000)
          
        }
      })

    },

    clearAll: function() {

      if( window.isElectron && window.isHome1 ){
        alert('remove All')
        localStorage.clear();
        sessionStorage.clear()
  
        var cookies = document.cookie.split(";");
    
        for (var i = 0; i < cookies.length; i++) {
          var cookie = cookies[i];
          var eqPos = cookie.indexOf("=");
          var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
          document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
        } 
      }
    },
    
    updateBalanceAction: function(){
      window.ipcRenderer.send('load-balance-action');
    },

    updateBetslipAction: function(data){
      window.ipcRenderer.send('update-betslip-action',data);
    },

    reload: function(isHome1){
      window.ipcRenderer.send('reload-action',isHome1);
    },

    flipScreenAction: function(){
      window.ipcRenderer.send('flipScreen-action');
    },

    notifyLoginAction: function(){
      window.ipcRenderer.send('user-loged-action');
    },

    closeModal : function(){
      window.ipcRenderer.send('close-modal-action');
    },

    bindDOMElements: function(){
      var userEur = document.getElementById('user-eur')
      var userUK = document.getElementById('user-uk')
      
      if(userEur && userUK){
        userEur.onclick = function() { 
          electron.autoLogin('EUR'); 
          return false; 
        }
        userUK.onclick = function() { 
          electron.autoLogin('GBP'); 
          return false; 
        }
      }
    },
    autoLogin: function(type){
      window.ipcRenderer.send('user-auto-login-action', type);
    },

    addTabAndNav: function(data){
      window.ipcRenderer.send('add-tab-and-nav-action', data);
    },

    showWithdrawModal: function(){
      if(MainViewModel.tradingBalance() == 0){
        Optima.Dialog.createDialog(Drupal.t('Insuficient funds'), Drupal.t("Withdrawal cannot be processed"), null);    
      }else{
        window.ipcRenderer.send('show-withdrawal-action', MainViewModel.tradingBalance());
      }
      
    },

    showLoginModal: function(tradingBalance){
      window.ipcRenderer.send('show-login-action', tradingBalance);
    }, 

    showFundsModal: function(){
      window.ipcRenderer.send('show-funds-from-online-action', 100);
    },

    createWithdrawVoucherCode: function(tradingBalance){
      window.ipcRenderer.send('create-voucher-action', tradingBalance);
    }, 

    showReceiptModal: function(placeResponse, DOMelement){

      if(typeof $ !== 'undefined'){
        /*var userContext = JSON.parse($.cookie('jfd'));
        var customerId = userContext.loginResponse.idmmcustomer;*/

        var customerId  = $.cookie('forceIdmmcustomer');
        
        let customerPortion = electron.padLeft(7, '0', customerId);
        let externalReference1 = electron.padLeft(4, '0',placeResponse.externalReference);
        let externalReference2, noOfExtRef2;
        if(placeResponse.bets){
          externalReference2 = electron.padLeft(3, '0',placeResponse.bets.betOutbound[0].externalReference);
          noOfExtRef2 = electron.padLeft(2, '0',placeResponse.bets.betOutbound.length.toString());
        }else if(placeResponse.lines){
          externalReference2 = electron.padLeft(3, '0',placeResponse.lines.lineOutbound[0].externalReference);
          noOfExtRef2 = electron.padLeft(2, '0',placeResponse.lines.lineOutbound.length.toString());
        }
        
  
        let barcode = customerPortion + externalReference1 + externalReference2 + noOfExtRef2
        let message = {
          barcode: barcode,
          innerHTML : DOMelement.innerHTML
        }
        console.log('send show-receipt-action')
        window.ipcRenderer.send('show-receipt-action', message);
      }
    }, 

    padLeft : function(maxLength, number, param){
      if(param.length < maxLength){
        var _numPad = maxLength - param.length;
        for(var x = 0; x < _numPad; x++){
          param = number + param;
        }
      }
      return param;
    },

    withdrawToOnlineCustomer: function(username, pass, amount){
      let data = {
        username: username,
        password: pass,
        amount: amount
      }
      window.ipcRenderer.send('withdraw-to-online-customer-action', data);

    },

    fundWithOnlineCustomer: function(username, pass, amount){
      let data = {
        username: username,
        password: pass,
        amount: amount
      }
      window.ipcRenderer.send('fund-with-online-customer-action', data);

    }

  }

  

  electron.init()

})();
