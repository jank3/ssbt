$(function() {
   
  let amount;

  window.ipcRenderer.send('modal-ready-dom-loaded-action');

  $('.close-btn').click(function(){
    electron.closeModal();
  });

  var withdraw = document.getElementById('ssbt-withdraw')
  var transfer = document.getElementById('ssbt-transfer')

  if(transfer && withdraw ){
    transfer.onclick = function() { 
      electron.showLoginModal(amount)
      return false; 
    }
    withdraw.onclick = function() { 
      electron.createWithdrawVoucherCode(amount)
      return false; 
    }
  }

  window.ipcRenderer.on('send-data-render', (event, message) => {
    if(message.amount){
      amount = message.amount
    }
  }); 

});

