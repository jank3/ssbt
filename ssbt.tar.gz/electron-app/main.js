if (require.main !== module) {
  require('update-electron-app')({
    logger: require('electron-log')
  })
}

const {app} = require('electron')
const {ipcMain} = require('electron');
const Connection = require('./assets/js/connection')
const BarcodeGenerator = require('./assets/js/barcodeGenerator')
const BetviewGenerator = require('./assets/js/betviewGenerator')


const Screen = require('./assets/js/screen')
const Wallet = require('./assets/js/wallet')
var dateFormat = require('dateformat');


app.commandLine.appendSwitch('touch-events', 'enabled');
app.commandLine.appendSwitch('enable-touch-events')
app.commandLine.appendSwitch('--enable-touch-events')
app.commandLine.appendSwitch('--emulate-touch-events')



let wallet, connection, screen, loginData

const debug = /--debug/.test(process.argv[2])

if (process.mas) app.setName('SSBT')


const SSBT = require('./configuration.json');

const defaultSettings = {
  width: 1920, 
  height: 1080,
  //kiosk: false,
  //fullscreen: false, 
  alwaysOnTop: debug ? false : true,
  movable : debug ? true : false,
  show: false,
  frame: debug ? true : false,
  contextIsolation: true,
  webSecurity: false,
  //resizable: false,
  webPreferences: {
    nodeIntegration: false,
    //preload: path.join(__dirname, '/assets/js/preload.js'),
  } 
};

/* METHODS */
let connectionSuccess = (frame) =>{
  debug && console.log('STOMP: Connection status'+frame);
  wallet.subscribeMoneyIn(moneyInSuccessCallback);
  wallet.subscribeVoucherProcess(voucherProcessSuccessCallback);
  wallet.subscribeWithdrawVoucherProcess(withdrawVoucherProcess)
  wallet.subscribeWithdrawToOnline(withdrawToOnlineProcess)
  wallet.subscribeFundWithOnline(fundWithOnlineProcess)

  screen.mainWindow.webContents.send('connection-ready-render')
  screen.secondaryWindow.webContents.send('connection-ready-render')
}

let connectionTries = 0;
let connectionFailure = (error) =>{
  debug && console.log('STOMP ERROR: ' + error);

  if(screen.mainWindow && screen.secondaryWindow){
    screen.mainWindow.webContents.send('connection-off-render')
    screen.secondaryWindow.webContents.send('connection-off-render')
  }

  if(connectionTries == SSBT.connnection.reconnectionTries){
    screen.mainWindow.webContents.send('lost-connection-render')
    screen.secondaryWindow.webContents.send('lost-connection-render')
    connectionTries = 0;
    return;
  }else{
    debug && console.log('STOMP: Reconecting in '+ SSBT.connnection.reconnectionTimeout / 1000+' seconds');
    setTimeout(function(){
      initializeConnection()
      connectionTries++;
    }, SSBT.connnection.reconnectionTimeout);
  }
}

let moneyInSuccessCallback = (data)=>{
  if(data){
    screen.mainWindow.webContents.send('update-balance-render',data)
    screen.secondaryWindow.webContents.send('update-balance-render',data)
  }
}

let voucherProcessSuccessCallback = (message)=>{
  if(message){
    screen.secondaryWindow.webContents.send('funds-process-voucher-render',message)
    screen.mainWindow.webContents.send('funds-process-voucher-render',message)
  }
}

let withdrawVoucherProcess = (message)=>{

  if(message.body && !message.error){
    var _callback = function(src){
      var now = new Date();

      let data = {
        base64Src: src,
        voucherResult: message.body.createVoucherResponse.createVoucherResult,
        amount: message.body.amount,
        date: dateFormat(now, "dddd, mmmm dS, yyyy, h:MM:ss TT")

      } 
      screen.createPrintPage('voucher', data);
    }

    BarcodeGenerator.generateCode(message.body.createVoucherResponse.createVoucherResult, _callback)
 
    screen.secondaryWindow.webContents.send('withdraw-process-voucher-render',message)
    screen.mainWindow.webContents.send('withdraw-process-voucher-render',message)

  }else if(message.error){
    screen.secondaryWindow.webContents.send('withdraw-process-voucher-render',message)
  }
}

let withdrawToOnlineProcess = (message)=>{
  screen.mainWindow.webContents.send('process-withdraw-to-online-render',message)
  screen.secondaryWindow.webContents.send('process-withdraw-to-online-render',message)
}

let fundWithOnlineProcess = (message)=>{
  screen.mainWindow.webContents.send('process-fund-with-online-render',message)
  screen.secondaryWindow.webContents.send('process-fund-with-online-render',message)
}

let initializeConnection =  ()=> {
  connection = new Connection({url: SSBT.wsUri}, connectionSuccess, connectionFailure)
  wallet = new Wallet(connection, connection.stompClient , screen.mainWindow, screen.secondaryWindow)
  
}
/* APP EVENTS */
app.on('ready', () => {

  screen = new Screen(defaultSettings,debug);
  initializeConnection();

  //testprint();
  //testBetReceiptStatus(0152679293203356)

})

let testBetReceiptStatus = (voucherCode) =>{
  var _callback = function(DOMelement){
    if(DOMelement && DOMelement.indexOf('ProcessRequest error') > -1){
      console.log('invalid bet recipt ->'+voucherCode)
      return;
    }
    let data = {
      receiptCode: voucherCode,
      DOMelement : DOMelement,
    }
    screen.mainWindow.webContents.send('process-bet-reicipt-status-render',data)
    screen.secondaryWindow.webContents.send('process-bet-reicipt-status-render',data)
  }
  BetviewGenerator.generateView(voucherCode, _callback)
}

let testprint =  ()=> {
   
  var _callback = function(src){
    let data = {
      base64Src: src,
      voucherResult: 'X8L33UV28E3EGBCT'
    }
    screen.createPrintPage('voucher',data);
  }
  BarcodeGenerator.generateCode('X8L33UV28E3EGBCT', _callback)

}


app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', function () {
  if (screen.mainWindow === null) {
    screen.createWindow()
  }
})



/* IPCMAIN */

ipcMain.on('ready-dom-loaded-action', () => {
  console.log('************************************');
  console.log('***************ON ready-dom-loaded-action');
  console.log('************************************');
  screen.mainWindow.webContents.send('user-auto-login-render',loginData)
  screen.secondaryWindow.webContents.send('user-auto-login-render',loginData)
});

ipcMain.on('splitScreen-action', () => {
  screen.flipScreen();
});

ipcMain.on('update-betslip-action', (event, data) => {
  screen.mainWindow.webContents.send('update-betslip-render',data)
  screen.secondaryWindow.webContents.send('update-betslip-render', data)
});

ipcMain.on('reload-action', (event, data) => {
  screen.mainWindow.webContents.send('reload-render',data)
  screen.secondaryWindow.webContents.send('reload-render', data)
});

ipcMain.on('user-loged-action', () => {
  screen.mainWindow.webContents.send('user-loged-render','mainWindow')
  screen.secondaryWindow.webContents.send('user-loged-render','secondaryWindow')
});

ipcMain.on('send-voucher-action', (event, voucherCode) => {

  if(voucherCode && voucherCode.length < 10){
    return;
  }

  if(isNaN(voucherCode)){
    wallet.sendVoucherCode(voucherCode);
  }else{

    var _callback = function(DOMelement){
      if(DOMelement && DOMelement.indexOf('ProcessRequest error') > -1){
        console.log('invalid bet recipt ->'+voucherCode)
        return;
      }
      let data = {
        receiptCode: voucherCode,
        DOMelement : DOMelement,
      }
      screen.mainWindow.webContents.send('process-bet-reicipt-status-render',data)
      screen.secondaryWindow.webContents.send('process-bet-reicipt-status-render',data)
    }
    BetviewGenerator.generateView(voucherCode, _callback)
  }
  
});

ipcMain.on('close-modal-action', () => {
  screen.closeModal();
});

ipcMain.on('load-balance-action', () => {
  screen.mainWindow.webContents.send('load-balance-render')
  screen.secondaryWindow.webContents.send('load-balance-render')
});


ipcMain.on('add-tab-and-nav-action', (event,data) => {
  screen.mainWindow.webContents.send('add-tab-and-nav-render',data)
  screen.secondaryWindow.webContents.send('add-tab-and-nav-render',data)
});



ipcMain.on('user-auto-login-action', (event, type) => {
  if(type == 'EUR'){
    loginData = SSBT.user1;
  }else{
    loginData = SSBT.user2;
  }
  
  screen.closeModal();

  screen.mainWindow.show();
  screen.secondaryWindow.show();

  if(!debug){
    screen.mainWindow.setFullScreen(true)
    screen.mainWindow.setKiosk(true)
    screen.secondaryWindow.setFullScreen(true)
    screen.secondaryWindow.setKiosk(true)
  }

});

ipcMain.on('show-withdrawal-action', (event, tradingBalance) => {
  let message = {amount : tradingBalance}
  screen.createModal('withdraw', message)
});

ipcMain.on('show-login-action', (event, tradingBalance) => {
  let message = {amount : tradingBalance}
  screen.closeModal();
  screen.createModal('login', message, 'large')
});

ipcMain.on('show-funds-from-online-action', (event, tradingBalance) => {
  let message = {amount : tradingBalance}
  screen.closeModal();
  screen.createModal('login-amount', message, 'large')
});

ipcMain.on('create-voucher-action', (event, tradingBalance) => {
  screen.closeModal();
  wallet.createWithdrawVoucherCode(tradingBalance);
});

ipcMain.on('withdraw-to-online-customer-action', (event, message) => {
  screen.closeModal();
  wallet.withdrawToOnline(message);
});

ipcMain.on('fund-with-online-customer-action', (event, message) => {
  screen.closeModal();
  wallet.fundWithOnline(message);
});


ipcMain.on('show-receipt-action', (event, message) => {
  if(message && message.barcode){

    var _callback = function(src){
      let data = {
        base64Src: src,
        DOMelement : message.innerHTML,
        receiptResult: message.barcode,
      }
      screen.createPrintPage('receipt',data);
    }
    BarcodeGenerator.generateCode(message.barcode, _callback)

  }
  
});




