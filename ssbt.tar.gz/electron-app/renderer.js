const { ipcRenderer } = require('electron');

(function() {

  ipcRenderer.on('send-data-render', (event, message) => {

    if(message.DOMelement){
      var content = document.getElementById('content')
      content.innerHTML += message.DOMelement
    }
   
    if(message.base64Src){
      var elem = document.createElement("img");
      elem.setAttribute("src", "data:image/png;base64," + message.base64Src );
      document.getElementById("barcode").appendChild(elem);
    }

    if(message.date){
      var content1 = document.getElementById('date')
      content1.innerHTML += message.date
    }

    if(message.voucherResult){
      var content2 = document.getElementById('voucherResult')
      content2.innerHTML += message.voucherResult
    }

    if(message.amount){
      var content3 = document.getElementById('amount')
      content3.innerHTML += message.amount
    }

    if(message.receiptResult){
      var content4 = document.getElementById('receiptResult')
      content4.innerHTML += message.receiptResult
    }


    
  });


})();