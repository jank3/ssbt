/*LOGIN*/

if (window.isElectron){
  window.isElectron && electron.splitScreenAction()
}

/*SPLIT SCREEN*/
if (window.isElectron){
  window.isElectron && electron.notifyLoginAction()
}


/**/
if (window.isElectron){
  window.isElectron && electron.notifyLoginAction()
}


scp /Users/jnjimenez/Desktop/ssbt-1.0.0.x86_64.rpm  optima@172.22.4.226:/home/optima/temp/

https://tech.amikelive.com/node-663/quick-tip-installing-nodejs-8-on-centos-7/


install electron
-------------------

 sudo npm install --unsafe-perm=true --allow-root
 
  vi package.json
  968  sudo vi package.json
  969  sudo npm install
  970  sudo vi package.json
  971  sudo npm install
  972  sudo npm install electron --verbose
  973  ls
  974  cd node_modules/
  975  ls
  976  cd electron* -fr
  977  cd ..
  978  sudo npm install
  979  vi /root/.npm/_logs/2019-01-15T14_17_49_219Z-debug.lo
  980  sudo npm install --unsafe-perm=true --allow-root
  981 npm install --save-dev electron

Websocket
http://172.22.4.102:8080/moneyIn?amount=9


https://spring.io/guides/gs/messaging-stomp-websocket/

http://172.22.5.96:8080/moneyIn?value=20

  file:///Users/jnjimenez/Desktop/test-stomp.html


  LoginViewModel.username('ssbt_1')
  LoginViewModel.password('Password1')
  LoginViewModel.login()


  LoginViewModel.username('ddtest')
  LoginViewModel.password('qwerty123')
  LoginViewModel.login()


   $('#login-name').val('ssbt_2')
   $('#login-pass').val('Password1')